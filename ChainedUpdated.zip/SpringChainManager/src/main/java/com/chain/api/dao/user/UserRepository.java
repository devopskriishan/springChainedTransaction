package com.chain.api.dao.user;

import org.springframework.data.jpa.repository.JpaRepository;

import com.chain.api.model.user.UserMultipleDB;


public interface UserRepository extends JpaRepository<UserMultipleDB, Integer> {
}