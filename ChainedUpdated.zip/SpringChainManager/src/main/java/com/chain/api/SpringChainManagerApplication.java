package com.chain.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.chain.api.dao.product.ProductRepository;
import com.chain.api.dao.user.UserRepository;
import com.chain.api.model.product.Product;
import com.chain.api.model.user.UserMultipleDB;

@SpringBootApplication
@RestController
@PropertySource({"classpath:persistence-multiple-db-boot.properties"})
public class SpringChainManagerApplication {

	@Autowired
	private SpringBootSender springbootsndr;
	
	
	@Autowired
    private UserRepository userRepository;
	
	@Autowired
	JmsConfig jmsConfig;
	
	@Autowired
	Environment env;
	
	@Autowired
	private ProductRepository productRepository;
	
		@RequestMapping("/getUsers")
	  	@Transactional(value="chainedTransactionManager")
	    public List<UserMultipleDB> whenCreatingUsersWithSameEmail_thenRollback() {
	       
			
			UserMultipleDB user1 = new UserMultipleDB();
	        user1.setName("John");
	        user1.setEmail("john@test.com");
	        user1.setAge(20);
	        user1 = userRepository.save(user1);
	        UserMultipleDB user2 = new UserMultipleDB();
	        user2.setName("John1");
	        user2.setEmail("john1@test.com");
	        user2.setAge(201);
	        user2= userRepository.save(user2);
	        
	        jmsConfig.jmsTemplate().convertAndSend(env.getProperty("input.queue"),"Test Message from Animesh");
	        try {
				springbootsndr.sendEvent();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
//	        try {
//				Thread.sleep(10000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
	        
	        Product product = new Product();
	        product.setName("2");
	        product.setId(2);
	        product.setPrice(20);
	        product = productRepository.save(product);

	        return userRepository.findAll();
	    }
	

	public static void main(String[] args) {
		SpringApplication.run(SpringChainManagerApplication.class, args);
	}

}
